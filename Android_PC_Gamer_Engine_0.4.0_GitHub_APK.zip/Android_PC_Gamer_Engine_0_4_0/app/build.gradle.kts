plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.pcgamer.engine"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.pcgamer.engine"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0"
        externalNativeBuild { cmake { cppFlags += "-std=c++17" } }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
}
