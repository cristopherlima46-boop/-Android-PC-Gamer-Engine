#include <jni.h>
#include <android/native_window_jni.h>
#include <vulkan/vulkan.h>
#include <string>
#include <vector>
#include <sstream>

static VkInstance instance = VK_NULL_HANDLE;
static VkSurfaceKHR surface = VK_NULL_HANDLE;
static ANativeWindow* nativeWindow = nullptr;
static VkPhysicalDevice gpu = VK_NULL_HANDLE;
static VkDevice device = VK_NULL_HANDLE;
static VkSwapchainKHR swapchain = VK_NULL_HANDLE;

static void cleanup() {
    if (device != VK_NULL_HANDLE) {
        if (swapchain) vkDestroySwapchainKHR(device, swapchain, nullptr);
        vkDeviceWaitIdle(device);
        vkDestroyDevice(device, nullptr);
        device = VK_NULL_HANDLE; swapchain = VK_NULL_HANDLE;
    }
    if (instance && surface) { vkDestroySurfaceKHR(instance, surface, nullptr); surface = VK_NULL_HANDLE; }
    if (nativeWindow) { ANativeWindow_release(nativeWindow); nativeWindow = nullptr; }
    if (instance) { vkDestroyInstance(instance, nullptr); instance = VK_NULL_HANDLE; }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_pcgamer_engine_MainActivity_nativeInit(JNIEnv* env, jclass, jobject jsurface) {
    cleanup();
    nativeWindow = ANativeWindow_fromSurface(env, jsurface);
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "Android PC Gamer Engine";
    app.apiVersion = VK_API_VERSION_1_0;

    const char* extensions[] = { VK_KHR_SURFACE_EXTENSION_NAME, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME };
    VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &app;
    ici.enabledExtensionCount = 2;
    ici.ppEnabledExtensionNames = extensions;
    VkResult r = vkCreateInstance(&ici, nullptr, &instance);
    if (r != VK_SUCCESS) {
        cleanup();
        return env->NewStringUTF("Vulkan indisponível: falha ao criar instância.");
    }

    VkAndroidSurfaceCreateInfoKHR sci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR};
    sci.window = nativeWindow;
    r = vkCreateAndroidSurfaceKHR(instance, &sci, nullptr, &surface);
    if (r != VK_SUCCESS) {
        cleanup();
        return env->NewStringUTF("Vulkan iniciou, mas não foi possível criar a superfície Android.");
    }

    uint32_t count = 0;
    vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (!count) {
        cleanup();
        return env->NewStringUTF("Nenhuma GPU Vulkan compatível foi encontrada.");
    }
    std::vector<VkPhysicalDevice> devices(count);
    vkEnumeratePhysicalDevices(instance, &count, devices.data());
    gpu = devices[0];
    VkPhysicalDeviceProperties props{};
    vkGetPhysicalDeviceProperties(gpu, &props);

    uint32_t qcount = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(gpu, &qcount, nullptr);
    std::vector<VkQueueFamilyProperties> queues(qcount);
    vkGetPhysicalDeviceQueueFamilyProperties(gpu, &qcount, queues.data());
    int graphics = -1, present = -1;
    for (uint32_t i = 0; i < qcount; ++i) {
        if (queues[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) graphics = (int)i;
        VkBool32 supported = VK_FALSE;
        vkGetPhysicalDeviceSurfaceSupportKHR(gpu, i, surface, &supported);
        if (supported) present = (int)i;
    }

    std::ostringstream out;
    out << "Vulkan ativo\nGPU: " << props.deviceName
        << "\nAPI: " << VK_VERSION_MAJOR(props.apiVersion) << "."
        << VK_VERSION_MINOR(props.apiVersion)
        << "\nFamílias de fila: " << qcount
        << "\nGráficos: " << (graphics >= 0 ? "sim" : "não")
        << " | Apresentação: " << (present >= 0 ? "sim" : "não")
        << "\nPróxima etapa: dispositivo lógico e swapchain.";
    return env->NewStringUTF(out.str().c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_pcgamer_engine_MainActivity_nativeResize(JNIEnv*, jclass, jint, jint) {
    // A criação da swapchain será adicionada após validar formatos e modos de apresentação.
}
extern "C" JNIEXPORT void JNICALL
Java_com_pcgamer_engine_MainActivity_nativeShutdown(JNIEnv*, jclass) { cleanup(); }
