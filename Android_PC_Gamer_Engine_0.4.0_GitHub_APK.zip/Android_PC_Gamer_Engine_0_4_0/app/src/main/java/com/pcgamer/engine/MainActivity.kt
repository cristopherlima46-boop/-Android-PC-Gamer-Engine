package com.pcgamer.engine

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var status: TextView
    private lateinit var library: LinearLayout
    private var nativeReady = false
    private val pickExe = 4102
    private val games = mutableListOf<Pair<String, Uri>>()

    companion object {
        init { System.loadLibrary("pcengine") }
        @JvmStatic external fun nativeInit(surface: Surface): String
        @JvmStatic external fun nativeResize(width: Int, height: Int)
        @JvmStatic external fun nativeShutdown()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = 4 or 1024 or 4096 or 512 or 2

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(0xFF090D16.toInt())
        }
        root.addView(label("ANDROID PC GAMER", 25f, 0xFFFFFFFF.toInt()))
        root.addView(label("GAME LIBRARY  •  EXPERIMENTAL", 12f, 0xFF75D7FF.toInt()))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFF17243A.toInt())
        }
        hero.addView(label("PC WINDOWS GAMES", 20f, 0xFFFFFFFF.toInt()))
        hero.addView(label("Importe um arquivo .EXE para adicioná-lo à biblioteca. A execução ainda depende da integração do Wine/Box64.", 14f, 0xFFD0D9E8.toInt()))
        val add = Button(this).apply {
            text = "＋  ADICIONAR JOGO (.EXE)"
            setOnClickListener { openExePicker() }
        }
        hero.addView(add)
        root.addView(hero)

        root.addView(label("MINHA BIBLIOTECA", 17f, 0xFFFFFFFF.toInt()))
        val scroll = ScrollView(this)
        library = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(library)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addEmptyState()

        status = label("Gráficos: aguardando superfície Vulkan…", 12f, 0xFF8FA6C7.toInt())
        root.addView(status)

        val surface = SurfaceView(this).apply { alpha = 0.01f }
        surface.holder.addCallback(this)
        root.addView(surface, LinearLayout.LayoutParams(1, 1))
        setContentView(root)
    }

    private fun label(textValue: String, size: Float, color: Int) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(4, 9, 4, 9)
    }

    private fun openExePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.microsoft.portable-executable",
                "application/octet-stream"
            ))
        }
        startActivityForResult(intent, pickExe)
    }

    @Deprecated("Use Activity Result API in a later iteration")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickExe && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Jogo Windows"
            games.add(name to uri)
            renderGames()
            Toast.makeText(this, "Arquivo adicionado à biblioteca. Execução ainda não habilitada.", Toast.LENGTH_LONG).show()
        }
    }

    private fun addEmptyState() {
        library.addView(label("Sua biblioteca está vazia. Toque em “Adicionar jogo” para selecionar um instalador ou executável.", 14f, 0xFF9EACC2.toInt()))
    }

    private fun renderGames() {
        library.removeAllViews()
        if (games.isEmpty()) { addEmptyState(); return }
        games.forEach { (name, uri) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 10, 14, 10)
                setBackgroundColor(0xFF141E2E.toInt())
            }
            card.addView(label(name, 16f, 0xFFFFFFFF.toInt()))
            card.addView(label("Windows • ${uri.lastPathSegment ?: "arquivo selecionado"}", 11f, 0xFF8FA6C7.toInt()))
            card.addView(label("STATUS: IMPORTADO — COMPATIBILIDADE PENDENTE", 10f, 0xFFFFC66D.toInt()))
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 6, 0, 6)
            library.addView(card, params)
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        val result = nativeInit(holder.surface)
        nativeReady = true
        status.text = "Vulkan: $result"
    }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (nativeReady) nativeResize(width, height)
    }
    override fun surfaceDestroyed(holder: SurfaceHolder) {
        if (nativeReady) { nativeShutdown(); nativeReady = false }
    }
    override fun onDestroy() {
        if (nativeReady) nativeShutdown()
        super.onDestroy()
    }
}
