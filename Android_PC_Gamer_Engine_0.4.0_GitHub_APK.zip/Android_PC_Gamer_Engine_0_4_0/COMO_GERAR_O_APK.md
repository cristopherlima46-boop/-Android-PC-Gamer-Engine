# Como gerar e baixar o APK — passo a passo

Este pacote está preparado para gerar o APK pela compilação automática do GitHub Actions. Você precisará de uma conta GitHub e conexão com a internet. Não precisa instalar Android Studio no celular.

## 1. Criar um repositório
1. Entre em https://github.com e faça login.
2. Toque no botão **+** e escolha **New repository**.
3. Nome: `Android-PC-Gamer-Engine`.
4. Marque **Public** (ou use Private, se preferir).
5. Crie o repositório.

## 2. Enviar os arquivos do projeto
1. Baixe e extraia `Android_PC_Gamer_Engine_0.4.0_GitHub_APK.zip`.
2. No repositório novo, escolha **Add file → Upload files**.
3. Envie o conteúdo que está dentro da pasta `Android_PC_Gamer_Engine_0_4_0` — envie também a pasta oculta `.github` e seu conteúdo.
4. Confirme em **Commit changes** na branch `main`.

Atenção: o arquivo `.github/workflows/android-apk.yml` precisa estar no caminho exato `.github/workflows/android-apk.yml` na raiz do repositório. Se o envio pelo celular esconder arquivos iniciados por ponto, use a opção de upload do site em modo desktop ou um computador e confira se a pasta `.github` foi enviada.

## 3. Iniciar a compilação
1. Abra a aba **Actions** do repositório.
2. Se aparecer uma tela de confirmação, habilite os GitHub Actions.
3. Escolha **Gerar APK Android** na lista de workflows.
4. Toque em **Run workflow** e confirme em **Run workflow** novamente.
5. Aguarde o trabalho terminar com um sinal verde. A primeira compilação pode demorar alguns minutos.

O workflow também inicia automaticamente quando você envia um commit para a branch `main`.

## 4. Baixar o APK
1. Abra a execução concluída na aba **Actions**.
2. Desça até **Artifacts**.
3. Baixe `PC-Gamer-Engine-0.4.0-debug-APK`.
4. Extraia o ZIP baixado. Dentro estará `app-debug.apk`.
5. Abra o APK no Android e autorize a instalação por essa origem, se o Android solicitar.

## Se a compilação falhar
Abra a execução em **Actions**, entre na etapa que ficou vermelha e copie a mensagem de erro. Ela permitirá corrigir o projeto. Não considere o APK pronto se o workflow não terminar com sucesso.

## Limitações desta versão
O arquivo gerado será um APK de depuração para testar a interface e a inicialização Vulkan. A versão 0.4.0 ainda não executa jogos de Windows: Wine/Box64 e a camada de compatibilidade gráfica ainda não foram integrados. O APK também não foi compilado nem testado previamente neste ambiente.
