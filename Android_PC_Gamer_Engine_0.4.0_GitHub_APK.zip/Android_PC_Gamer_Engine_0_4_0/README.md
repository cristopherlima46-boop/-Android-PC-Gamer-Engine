# Android PC Gamer Engine — 0.4.0

Protótipo Android Kotlin + C++/JNI + Vulkan, com interface de biblioteca inspirada em launchers de jogos para PC.

## Novidades 0.4.0
- Tela inicial em estilo biblioteca de jogos.
- Seletor Android para importar arquivos executáveis/instaladores.
- Lista local em memória dos arquivos selecionados durante a sessão.
- Mantém o diagnóstico Vulkan do protótipo 0.3.0.

## Importante: o que funciona e o que ainda não funciona
Esta versão **não executa jogos Windows**. A importação apenas seleciona e lista o arquivo; ela não instala nem inicia o jogo.
Ainda precisam ser integrados e testados: ambiente Linux compatível, Wine, Box64, tradução DirectX/Vulkan (por exemplo DXVK quando aplicável), áudio, controles, gerenciamento de prefixos e permissões de arquivos. Esses componentes não são incluídos neste ZIP.

O Moto G75 5G com Snapdragon 6 Gen 3/Adreno 710 é o dispositivo-alvo de teste, mas não há garantia de que jogos como Resident Evil 3 Remake ou Resident Evil 6 rodem com desempenho aceitável.

## Compilar
1. Extraia o ZIP e abra a pasta no Android Studio em um computador.
2. Instale Android SDK 35, NDK e CMake 3.22.1.
3. Sincronize o Gradle e compile a variante `debug`.
4. Instale o APK em um dispositivo Android compatível com os requisitos do projeto.

O projeto ainda não foi compilado nem testado fisicamente no Moto G75. O workflow GitHub Actions pode ser usado para tentar gerar o APK.


## Gerar o APK
Consulte **COMO_GERAR_O_APK.md**. O workflow `.github/workflows/android-apk.yml` compila `app-debug.apk` e publica o arquivo na seção **Artifacts** da execução do GitHub Actions.
